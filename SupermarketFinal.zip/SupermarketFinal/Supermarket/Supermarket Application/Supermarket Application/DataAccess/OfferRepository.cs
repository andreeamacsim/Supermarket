﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data.SqlClient; 

namespace Supermarket_Application.DataAccess
{
    public class OfferRepository
    {
        private SupermarketDbContext _context;

        public OfferRepository(SupermarketDbContext context)
        {
            _context = context;
        }

        public void Add(Offer offer)
        {
            var query = "INSERT INTO Offers (ProductID, OfferReason, DiscountPercentage, ValidFrom, ValidUntil, IsActive) VALUES (@ProductID, @OfferReason, @DiscountPercentage, @ValidFrom, @ValidUntil, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@ProductID", offer.ProductID),
                new SqlParameter("@OfferReason", offer.OfferReason),
                new SqlParameter("@DiscountPercentage", offer.DiscountPercentage),
                new SqlParameter("@ValidFrom", offer.ValidFrom),
                new SqlParameter("@ValidUntil", offer.ValidUntil),
                new SqlParameter("@IsActive", offer.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

       
        public Offer GetById(int id)
        {
            var query = "SELECT * FROM Offers WHERE OfferID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Offer>(query, parameter).FirstOrDefault();
        }

        
        public IEnumerable<Offer> GetAll()
        {
            var query = "SELECT * FROM Offers";
            return _context.Database.SqlQuery<Offer>(query).ToList();
        }

       
        public void Update(Offer offer)
        {
            var query = "UPDATE Offers SET ProductID = @ProductID, OfferReason = @OfferReason, DiscountPercentage = @DiscountPercentage, ValidFrom = @ValidFrom, ValidUntil = @ValidUntil, IsActive = @IsActive WHERE OfferID = @OfferID";
            var parameters = new[]
            {
                new SqlParameter("@ProductID", offer.ProductID),
                new SqlParameter("@OfferReason", offer.OfferReason),
                new SqlParameter("@DiscountPercentage", offer.DiscountPercentage),
                new SqlParameter("@ValidFrom", offer.ValidFrom),
                new SqlParameter("@ValidUntil", offer.ValidUntil),
                new SqlParameter("@IsActive", offer.IsActive),
                new SqlParameter("@OfferID", offer.OfferID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

     
        public void Delete(int id)
        {
            var query = "UPDATE Offers SET IsActive = 0 WHERE OfferID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
