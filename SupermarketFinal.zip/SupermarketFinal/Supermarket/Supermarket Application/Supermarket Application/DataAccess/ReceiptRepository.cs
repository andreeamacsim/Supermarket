﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient; 

namespace Supermarket_Application.DataAccess
{
    public class ReceiptRepository
    {
        private SupermarketDbContext _context;

        public ReceiptRepository(SupermarketDbContext context)
        {
            _context = context;
        }

       
        public void Add(Receipt receipt)
        {
            var query = "INSERT INTO Receipts (DateIssued, CashierID, TotalAmount, IsActive) VALUES (@DateIssued, @CashierID, @TotalAmount, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@DateIssued", receipt.DateIssued),
                new SqlParameter("@CashierID", receipt.CashierID),
                new SqlParameter("@TotalAmount", receipt.TotalAmount),
                new SqlParameter("@IsActive", receipt.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

      
        public Receipt GetById(int id)
        {
            var query = "SELECT * FROM Receipts WHERE ReceiptID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Receipt>(query, parameter).FirstOrDefault();
        }

      
        public IEnumerable<Receipt> GetAll()
        {
            var query = "SELECT * FROM Receipts";
            return _context.Database.SqlQuery<Receipt>(query).ToList();
        }

      
        public void Update(Receipt receipt)
        {
            var query = "UPDATE Receipts SET DateIssued = @DateIssued, CashierID = @CashierID, TotalAmount = @TotalAmount, IsActive = @IsActive WHERE ReceiptID = @ReceiptID";
            var parameters = new[]
            {
                new SqlParameter("@DateIssued", receipt.DateIssued),
                new SqlParameter("@CashierID", receipt.CashierID),
                new SqlParameter("@TotalAmount", receipt.TotalAmount),
                new SqlParameter("@IsActive", receipt.IsActive),
                new SqlParameter("@ReceiptID", receipt.ReceiptID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var query = "UPDATE Receipts SET IsActive = 0 WHERE ReceiptID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
