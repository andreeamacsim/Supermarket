﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient; 

namespace Supermarket_Application.DataAccess
{
    public class ManufacturerRepository
    {
        private SupermarketDbContext _context;

        public ManufacturerRepository(SupermarketDbContext context)
        {
            _context = context;
        }

     
        public void Add(Manufacturer manufacturer)
        {
            var query = "INSERT INTO Manufacturers (ManufacturerName, CountryOfOrigin, IsActive) VALUES (@ManufacturerName, @CountryOfOrigin, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@ManufacturerName", manufacturer.ManufacturerName),
                new SqlParameter("@CountryOfOrigin", manufacturer.CountryOfOrigin),
                new SqlParameter("@IsActive", manufacturer.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

       
        public Manufacturer GetById(int id)
        {
            var query = "SELECT * FROM Manufacturers WHERE ManufacturerID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Manufacturer>(query, parameter).FirstOrDefault();
        }

       
        public IEnumerable<Manufacturer> GetAll()
        {
            var query = "SELECT * FROM Manufacturers";
            return _context.Database.SqlQuery<Manufacturer>(query).ToList();
        }

        
        public void Update(Manufacturer manufacturer)
        {
            var query = "UPDATE Manufacturers SET ManufacturerName = @ManufacturerName, CountryOfOrigin = @CountryOfOrigin, IsActive = @IsActive WHERE ManufacturerID = @ManufacturerID";
            var parameters = new[]
            {
                new SqlParameter("@ManufacturerName", manufacturer.ManufacturerName),
                new SqlParameter("@CountryOfOrigin", manufacturer.CountryOfOrigin),
                new SqlParameter("@IsActive", manufacturer.IsActive),
                new SqlParameter("@ManufacturerID", manufacturer.ManufacturerID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var query = "UPDATE Manufacturers SET IsActive = 0 WHERE ManufacturerID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
