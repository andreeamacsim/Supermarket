﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data.SqlClient;

namespace Supermarket_Application.DataAccess
{
    public class UserRepository
    {
        private SupermarketDbContext _context;

        public UserRepository(SupermarketDbContext context)
        {
            _context = context;
        }


        public void Add(User user)
        {
            var query = "INSERT INTO Users (Username, PasswordHash, UserType, IsActive) VALUES (@Username, @PasswordHash, @UserType, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@Username", user.Username),
                new SqlParameter("@PasswordHash", user.PasswordHash),
                new SqlParameter("@UserType", user.UserType),
                new SqlParameter("@IsActive", user.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public User GetById(int id)
        {
            var query = "SELECT * FROM Users WHERE UserID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<User>(query, parameter).FirstOrDefault();
        }

        public IEnumerable<User> GetAll()
        {
            var query = "SELECT * FROM Users";
            return _context.Database.SqlQuery<User>(query).ToList();
        }

   
        public void Update(User user)
        {
            var query = "UPDATE Users SET Username = @Username, PasswordHash = @PasswordHash, UserType = @UserType, IsActive = @IsActive WHERE UserID = @UserID";
            var parameters = new[]
            {
                new SqlParameter("@Username", user.Username),
                new SqlParameter("@PasswordHash", user.PasswordHash),
                new SqlParameter("@UserType", user.UserType),
                new SqlParameter("@IsActive", user.IsActive),
                new SqlParameter("@UserID", user.UserID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var query = "UPDATE Users SET IsActive = 0 WHERE UserID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }

   
        public User Authenticate(string username, string password)
        {
            var query = "SELECT * FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash AND IsActive = 1";
            var parameters = new[]
            {
                new SqlParameter("@Username", username),
                new SqlParameter("@PasswordHash", password)
            };
            return _context.Database.SqlQuery<User>(query, parameters).FirstOrDefault();
        }
    }
}
