﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data.SqlClient; 
using System.Configuration;
using System;

namespace Supermarket_Application.DataAccess
{
    public class StockRepository
    {
        private SupermarketDbContext _context;

        public StockRepository(SupermarketDbContext context)
        {
            _context = context;
        }

        private decimal GetMarkupPercentage()
        {
            return Convert.ToDecimal(ConfigurationManager.AppSettings["MarkupPercentage"]);
        }

        public void Add(Stock stock)
        {
            decimal markupPercentage = GetMarkupPercentage();
            stock.SellingPrice = stock.PurchasePrice + (stock.PurchasePrice * markupPercentage / 100);

            var query = "INSERT INTO Stock (ProductID, Quantity, UnitOfMeasure, ProvisioningDate, ExpirationDate, PurchasePrice, SellingPrice, IsActive) VALUES (@ProductID, @Quantity, @UnitOfMeasure, @ProvisioningDate, @ExpirationDate, @PurchasePrice, @SellingPrice, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@ProductID", stock.ProductID),
                new SqlParameter("@Quantity", stock.Quantity),
                new SqlParameter("@UnitOfMeasure", stock.UnitOfMeasure),
                new SqlParameter("@ProvisioningDate", stock.ProvisioningDate),
                new SqlParameter("@ExpirationDate", stock.ExpirationDate),
                new SqlParameter("@PurchasePrice", stock.PurchasePrice),
                new SqlParameter("@SellingPrice", stock.SellingPrice),
                new SqlParameter("@IsActive", stock.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        
        public Stock GetById(int id)
        {
            var query = "SELECT * FROM Stock WHERE StockID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Stock>(query, parameter).FirstOrDefault();
        }


        public IEnumerable<Stock> GetAll()
        {
            var query = "SELECT * FROM Stock";
            return _context.Database.SqlQuery<Stock>(query).ToList();
        }


        public void Update(Stock stock)
        {
            var existingStock = _context.Database.SqlQuery<Stock>("SELECT * FROM Stock WHERE StockID = @StockID", new SqlParameter("@StockID", stock.StockID)).FirstOrDefault();
            if (existingStock == null)
            {
                throw new ArgumentException("Stock isn't found");
            }

            if (existingStock.PurchasePrice != stock.PurchasePrice)
            {
                throw new InvalidOperationException("Modification of purchase price is not allowed after entry.");
            }

            if (stock.SellingPrice < stock.PurchasePrice)
            {
                throw new InvalidOperationException("Selling price cannot be less than the purchase price.");
            }

            var query = "UPDATE Stock SET Quantity = @Quantity, UnitOfMeasure = @UnitOfMeasure, ProvisioningDate = @ProvisioningDate, ExpirationDate = @ExpirationDate, SellingPrice = @SellingPrice, IsActive = @IsActive WHERE StockID = @StockID";
            var parameters = new[]
            {
                new SqlParameter("@Quantity", stock.Quantity),
                new SqlParameter("@UnitOfMeasure", stock.UnitOfMeasure),
                new SqlParameter("@ProvisioningDate", stock.ProvisioningDate),
                new SqlParameter("@ExpirationDate", stock.ExpirationDate),
                new SqlParameter("@SellingPrice", stock.SellingPrice),
                new SqlParameter("@IsActive", stock.IsActive),
                new SqlParameter("@StockID", stock.StockID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var query = "UPDATE Stock SET IsActive = 0 WHERE StockID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
