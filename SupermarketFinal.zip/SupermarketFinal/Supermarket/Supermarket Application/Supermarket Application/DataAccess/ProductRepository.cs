﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data.SqlClient;

namespace Supermarket_Application.DataAccess
{
    public class ProductRepository
    {
        private SupermarketDbContext _context;

        public ProductRepository(SupermarketDbContext context)
        {
            _context = context;
        }

        public void Add(Product product)
        {
            var query = "INSERT INTO Products (ProductName, Barcode, CategoryID, ManufacturerID, IsActive) VALUES (@ProductName, @Barcode, @CategoryID, @ManufacturerID, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@ProductName", product.ProductName),
                new SqlParameter("@Barcode", product.Barcode),
                new SqlParameter("@CategoryID", product.CategoryID),
                new SqlParameter("@ManufacturerID", product.ManufacturerID),
                new SqlParameter("@IsActive", product.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

      
        public Product GetById(int id)
        {
            var query = "SELECT * FROM Products WHERE ProductID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Product>(query, parameter).FirstOrDefault();
        }

        
        public IEnumerable<Product> GetAll()
        {
            var query = "SELECT * FROM Products";
            return _context.Database.SqlQuery<Product>(query).ToList();
        }

     
        public void Update(Product product)
        {
            var query = "UPDATE Products SET ProductName = @ProductName, Barcode = @Barcode, CategoryID = @CategoryID, ManufacturerID = @ManufacturerID, IsActive = @IsActive WHERE ProductID = @ProductID";
            var parameters = new[]
            {
                new SqlParameter("@ProductName", product.ProductName),
                new SqlParameter("@Barcode", product.Barcode),
                new SqlParameter("@CategoryID", product.CategoryID),
                new SqlParameter("@ManufacturerID", product.ManufacturerID),
                new SqlParameter("@IsActive", product.IsActive),
                new SqlParameter("@ProductID", product.ProductID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

       
        public void Delete(int id)
        {
            var query = "UPDATE Products SET IsActive = 0 WHERE ProductID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
