﻿using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient; 

namespace Supermarket_Application.DataAccess
{
    public class CategoryRepository
    {
        private SupermarketDbContext _context;

        public CategoryRepository(SupermarketDbContext context)
        {
            _context = context;
        }

        public void Add(Category category)
        {
            var query = "INSERT INTO Categories (CategoryName, IsActive) VALUES (@CategoryName, @IsActive)";
            var parameters = new[]
            {
                new SqlParameter("@CategoryName", category.CategoryName),
                new SqlParameter("@IsActive", category.IsActive)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        public Category GetById(int id)
        {
            var query = "SELECT * FROM Categories WHERE CategoryID = @id";
            var parameter = new SqlParameter("@id", id);
            return _context.Database.SqlQuery<Category>(query, parameter).FirstOrDefault();
        }

       
        public IEnumerable<Category> GetAll()
        {
            var query = "SELECT * FROM Categories";
            return _context.Database.SqlQuery<Category>(query).ToList();
        }

        
        public void Update(Category category)
        {
            var query = "UPDATE Categories SET CategoryName = @CategoryName, IsActive = @IsActive WHERE CategoryID = @CategoryID";
            var parameters = new[]
            {
                new SqlParameter("@CategoryName", category.CategoryName),
                new SqlParameter("@IsActive", category.IsActive),
                new SqlParameter("@CategoryID", category.CategoryID)
            };
            _context.Database.ExecuteSqlCommand(query, parameters);
            _context.SaveChanges();
        }

        
        public void Delete(int id)
        {
            var query = "UPDATE Categories SET IsActive = 0 WHERE CategoryID = @id";
            var parameter = new SqlParameter("@id", id);
            _context.Database.ExecuteSqlCommand(query, parameter);
            _context.SaveChanges();
        }
    }
}
