﻿using Supermarket_Application.Views;
using System;
using System.Windows.Input;

namespace Supermarket_Application.ViewModels
{
    public class CashierViewModel
    {
        public ICommand OpenSearchCommand { get; }
        public ICommand AddReceiptCommand { get; }

        public ICommand ViewReceiptCommand { get; }
        public CashierViewModel()
        {
            OpenSearchCommand = new RelayCommand(param => OpenSearchWindow());
            AddReceiptCommand = new RelayCommand(param => OpenAddReceiptWindow());
            ViewReceiptCommand = new RelayCommand(param => OpenViewReceiptWindow());
        }

        private void OpenViewReceiptWindow()
        {
            var viewReceipt = new ViewReceiptView();
            viewReceipt.Show();
        }

        private void OpenAddReceiptWindow()
        {
            var addReceipt = new AddReceiptView();
            addReceipt.Show();
        }

        private void OpenSearchWindow()
        {
            var searchWindow = new CashierSearchView();
            searchWindow.ShowDialog();
        }
    }
}
