﻿using Supermarket_Application.DataAccess;
using Supermarket_Application.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Supermarket_Application.ViewModels
{
    public class CategoryTotalPriceViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<CategoryTotalPriceItem> CategoryTotalPrices { get; set; }

        public CategoryTotalPriceViewModel()
        {
            LoadCategoryTotalPrices();
        }

        private void LoadCategoryTotalPrices()
        {
            CategoryTotalPrices = new ObservableCollection<CategoryTotalPriceItem>();

            using (var dbContext = new SupermarketDbContext())
            {
                string sql = @"
            SELECT c.CategoryName, SUM(s.SellingPrice) AS TotalPrice
            FROM Products p
            INNER JOIN Stock s ON p.ProductID = s.ProductID
            INNER JOIN Categories c ON p.CategoryID = c.CategoryID
            WHERE s.SellingPrice IS NOT NULL AND p.IsActive = 1
            GROUP BY c.CategoryName";

                var categoryTotalPrices = dbContext.Database.SqlQuery<CategoryTotalPriceItem>(sql).ToList();

                foreach (var categoryTotalPrice in categoryTotalPrices)
                {
                    CategoryTotalPrices.Add(categoryTotalPrice);
                }
            }
        }





        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class CategoryTotalPriceItem
    {
        public string CategoryName { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
